import { Component, OnInit } from '@angular/core';
import { UpdateTotalService } from './services/UpdateTotalService';
import { CalculatorModel } from './models/CalculatorModel';

const ON_SCREEN_KEYBOARD = [
  ['7', '8', '9', '/'],
  ['4', '5', '6', '*'],
  ['1', '2', '3', '-'],
  ['0', '.', '=', '+']
];

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [UpdateTotalService, CalculatorModel]
})

export class AppComponent implements OnInit {
  onScreenKeyboard = ON_SCREEN_KEYBOARD;
  total:string;

  constructor(private updateTotalService:UpdateTotalService){}

  ngOnInit(): void {
    this.total = this.updateTotalService.reset();
  }

  updateTotal(value: string){
    switch (value) {
        case 'AC':
            this.total = this.updateTotalService.reset();
            break;
        case '=':
            this.total = this.updateTotalService.calculate();
            break;
        case '+':
        case '-':
        case '/':
        case '*':
        case '.':
            this.total = this.updateTotalService.addSymbol(value);
            break;
        default:
            this.total = this.updateTotalService.addValue(value);
            break;
    }
  }
}

