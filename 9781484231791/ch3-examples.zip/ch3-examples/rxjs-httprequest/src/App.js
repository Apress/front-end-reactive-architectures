import Rx from "rxjs";

const URL = "https://jsonplaceholder.typicode.com/users";

const simplifyUserData = (user) => {
    return {
        name: user.name,
        email: user.email,
        website: user.website
    }
}

const intervalObs = Rx.Observable.interval(1000)
                                 .take(2)
                                 .mergeMap(_ => fetch(URL))
                                 .mergeMap(data => data.json())
                                 .mergeAll()
                                 .map(simplifyUserData)

intervalObs.subscribe(user => {
    console.log(`user name is ${user.name}`);
    console.log(`user email is ${user.email}`);
    console.log(`user website is ${user.website}`);
    console.log('------------------------------');
},
error =>  console.error("error", error),
complete => console.log("completed"))