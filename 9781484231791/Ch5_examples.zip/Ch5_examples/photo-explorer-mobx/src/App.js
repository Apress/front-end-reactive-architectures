import React from 'react';
import ReactDOM from 'react-dom';
import {observer, Provider} from 'mobx-react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import Form from './components/Form';
import Grid from './components/Grid';
import SelectedPicture from './components/SelectedPicture';
import * as stores from './stores/Stores';

const style = {
    cont: {
        width: '100%',
        margin: 'auto'
    },
    child: {
        float: 'left'
    }
}

@observer
export class App extends React.Component{
    render(){
        return (
        <Provider {...stores}>
            <MuiThemeProvider>
                <div>
                    <Form/>
                    <Grid style={style.child}/>
                    <SelectedPicture style={style.child}/>
                </div>
            </MuiThemeProvider>
        </Provider>)
    }
}

ReactDOM.render(
    <App/>,
    document.getElementById("app")
);