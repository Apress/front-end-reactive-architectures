import Rx from "rxjs";
import t from "transducers-js";

const data = [1,2,10,1,3,9,6,13,11,10,10,3,19,18,17,15,4,8,4];

const filter = value => value % 2 === 0;
const removeDuplicate = (arr, value) => {
   if(arr.indexOf(value) < 0)
        arr.push(value);

    return arr
}
const reduce = (acc, value) => acc + value;

const evenUniqueArr = t.transduce(t.filter(filter), removeDuplicate, [], data);
const calculateSum = t.reduce(reduce, 0, evenUniqueArr)
console.log(calculateSum);