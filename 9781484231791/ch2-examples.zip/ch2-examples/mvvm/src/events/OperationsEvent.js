export default {
    CALCULATE_EVENT: "CalculateEvt"
}