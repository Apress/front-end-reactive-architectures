import {div, h3, img, p} from '@cycle/dom';
import moment from 'moment';

const generateNext5Days = forecasts => {
    const list = forecasts.map(forecast => div(".forecast-box", [
            h3(moment(forecast.date).format("dddd Do MMM")),
            p(`min ${forecast.day.mintemp_c}°C - max ${forecast.day.maxtemp_c}°C`),
            img(".forecast-img", {
                props: {
                    src: `http:${forecast.day.condition.icon}`
                }
            }),
            p(".status", forecast.day.condition.text)
        ])
    );

    return div(".forecasts-container", list)
}

const view = state$ => state$.map(state => generateNext5Days(state.forecasts))

export const FutureForecast = sources => {
    const state$ = sources.onion.state$;
    const vdom$ = view(state$)

    return {
        DOM: vdom$
    }
}