import Ember from 'ember';
import AppState from "../helpers/ApplicationState";

export default Ember.Controller.extend({
    onScreenKeyboard: [
        ["7", "8", "9", "/"],
        ["4", "5", "6", "*"],
        ["1", "2", "3", "-"],
        ["0", ".", "=", "+"]
    ],
    actions:{
        updateTotal(value){
            let result;
            let model = this.store.peekRecord('calculator', 1);

            switch (value) {
                case "AC":
                    model.set("total", 0);
                    model.set("state", AppState.FIRST_OPERATION);
                    break;      
                case "=":
                    result = math.eval(model.get("total"));
                    model.set("total", result);
                    model.set("state", AppState.FIRST_OPERATION);
                    break;
                case "+":
                case "-":
                case "/":
                case "*":
                case ".":
                    result = checkSymbol(model.get("total"), value, model.get("state"));
                    model.set("total", result);
                    model.set("state", AppState.CALCULATING);
                    break;
                default:
                    result = getValue(model.get("total"), value, model.get("state"));
                    model.set("total", result);
                    model.set("state", AppState.CALCULATING);
                    break;
            }
        }
    }
});

function checkSymbol(current, value, state){
    let str = current;

    if(state === FIRST_OPERATION){
       return str + value;
    }

    return !isNaN(str.charAt(str.length - 1)) ? str + value : str.substr(0, str.length - 1) + value;
}

function getValue(current, value, state){
    return (current == 0 || state === AppState.FIRST_OPERATION) ? value : current + value;
}