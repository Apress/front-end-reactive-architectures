export const FIRST_OPERATION = "firstOpearation";
export const IN_PROGRESS_OPERATION = "inProgressOpearation";