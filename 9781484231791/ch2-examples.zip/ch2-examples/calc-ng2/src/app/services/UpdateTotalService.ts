import { Injectable } from '@angular/core';
import { CalculatorModel } from '../models/CalculatorModel';
import { VALUE, SYMBOL } from '../utils/CalculatorTypes';

@Injectable()
export class UpdateTotalService{
    constructor(private model:CalculatorModel){}

    calculate(){
        this.model.calculate();
        return this.model.total;
    }

    addValue(value){
        this.model.add(value, VALUE);
        return this.model.total;
    }

    addSymbol(value){
        this.model.add(value, SYMBOL);
        return this.model.total;
    }

    reset(){
        this.model.reset();
        return this.model.total;
    }

}