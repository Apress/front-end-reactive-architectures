import  math from "mathjs";
import { CALCULATE, INIT, APPEND, reset } from "../actions/CalculatorActions";
import {resultHandler} from "../utils/ResultHandler";

const calculation = (state = reset(), action) => {
    switch (action.type) {
        case CALCULATE:
            return {
                type: action.type,
                result: math.eval(state.result)
            }
            break;
        
        case APPEND:
            return {
                type: action.type,
                result: resultHandler(state, action.toAppend)
            }
            break;
        
        case INIT:
            return {
                type: action.type,
                result: resultHandler(state, action.toAppend)
            }
            break;
    
        default:
            return state;
            break;
    }
} 

export default calculation