export const VALUE:string = "value";
export const SYMBOL:string = "symbol";