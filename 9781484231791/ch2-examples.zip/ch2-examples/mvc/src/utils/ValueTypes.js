export const SYMBOL = "symbol";
export const NUMERIC = "numeric";