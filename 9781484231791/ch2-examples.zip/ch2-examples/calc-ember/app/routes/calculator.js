import Ember from 'ember';
import AppState from "../helpers/ApplicationState";

export default Ember.Route.extend({
    model(){
        this.store.push({
            data:[{
                id: 1,
                type: "calculator",
                attributes: {
                    total: "0",
                    state: AppState.FIRST_OPERATION
                },
                relationships: {}
            }]
        });

        return this.store.peekRecord('calculator', 1);
    }
});