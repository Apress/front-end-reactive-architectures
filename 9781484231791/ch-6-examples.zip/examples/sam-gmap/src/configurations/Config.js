export const REGION = "eu";
export const INIT_COUNTRY = "GB";
export const URL = "https://restcountries.eu/rest/v2/regionalbloc/";
export const STATUS = {
    INIT: "initial",
    SELECT_COUNTRY: "select_country"
}