export const ulStyle = {
    userSelect: "none",
    color: "green",
    fontSize: "20px",
    fontFamily: "Arial, sans",
    listStyleType: "none",
    margin: 0,
    padding: 0,
    overflow: "hidden"
}

export const btnStyle = {
    cursor: "pointer",
    float: "left",
    textAlign: "center",
    width: "20px",
    padding: "20px",
    margin:"5px",
    border: "1px solid black"
}

export const acStyle = {
    cursor: "pointer",
    float: "left",
    textAlign: "center",
    width: "237px",
    padding: "20px",
    margin:"5px",
    border: "1px solid black"
}

export const displayStyle = {
    backgroundColor: "DimGrey",
    color: "white",
    fontFamily: "Arial, sans",
    fontSize: "30px",
    width: "239px",
    padding: "20px",
    margin:"5px",
    overflow: "hidden"
}