import { Injectable } from '@angular/core';
import { VALUE, SYMBOL } from '../utils/CalculatorTypes';
import { IN_PROGRESS_OPERATION, FIRST_OPERATION } from '../utils/CalculatorStates';

declare var math: any;

@Injectable()
export class CalculatorModel{
    private state:string;
    private totalOperation:string;

    constructor(){
        this.state = FIRST_OPERATION;
        this.totalOperation = '0';
    }

    get total(){
        return this.totalOperation;
    }

    reset(){
        this.totalOperation = '0';
        this.state = FIRST_OPERATION;
    }

    add(value, type){
        if(type === VALUE){
            this.totalOperation = this.getValue(value);
        } else {
            this.totalOperation = this.checkSymbol(value);
        }
        this.state = IN_PROGRESS_OPERATION;
    }

    calculate(){
        this.totalOperation = math.eval(this.totalOperation);
        this.state = FIRST_OPERATION;
    }

    checkSymbol(value){
        const str = this.totalOperation;

        if(this.state === FIRST_OPERATION){
            return str + value;
        }

        return !isNaN(Number(str.charAt(str.length - 1))) ? str + value : str.substr(0, str.length - 1) + value
    }

    getValue(value){
        return (this.totalOperation === '0' || this.state === FIRST_OPERATION) ? value : this.totalOperation + value;
    }
}