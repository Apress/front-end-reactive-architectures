import onionify from 'cycle-onionify';
import xs from 'xstream';
import {div, input, button, h1} from '@cycle/dom';

const INIT_CITY = "London";
const CITY_SEARCH = "citySearchAction";
const CATEGORY = "forecast";

const getRequest = city => ({
        type: CITY_SEARCH,
        city: city,
        url: `http://api.apixu.com/v1/forecast.json?key=04ca1fa2705645e4830214415172307&q=${city}&days=7`,
        category: CATEGORY
})

const getForm = location => div(".form", [
    h1(`Your forecasts in ${location.city}`),
    input("#location-input", {props: {value: `${location.city}`}}),
    button("#location-btn", "get forecasts")
])

const parseResponse = response => JSON.parse(response.text);
const simplifyData = data => function changeState(prevState) {
                                return {
                                    city: data.location.name,
                                    current: data.current,
                                    forecasts: data.forecast.forecastday
                                }
                            }

const model = (actions$, HTTP) => {
    const reducer$ = HTTP.select(CATEGORY)
               .flatten()
               .map(parseResponse)
               .map(simplifyData)

    return reducer$
}

const intent = DOM => {
    const input$ = DOM.select("#location-input").events("focusout")
                      .map(evt => evt.target.value);
    const btn$ = DOM.select("#location-btn").events("mousedown");  

    return xs.combine(input$, btn$)
             .map(([city, mouseEvt]) => getRequest(city))
             .startWith(getRequest(INIT_CITY))

}

const view = state$ => state$.map(state => getForm(state))

export const CityForm = sources => {
    const state$ = sources.onion.state$;
    const actions$ = intent(sources.DOM);
    const reducer$ = model(actions$, sources.HTTP);
    const vdom$ = view(state$);

    return {
        DOM: vdom$,
        onion: reducer$,
        HTTP: actions$
    }
}