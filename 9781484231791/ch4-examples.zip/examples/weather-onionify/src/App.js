import xs from 'xstream';
import {run} from '@cycle/run';
import {makeDOMDriver, div, h1} from '@cycle/dom';
import {makeHTTPDriver} from '@cycle/http';
import isolate from '@cycle/isolate';
import onionify from 'cycle-onionify';
import {CityForm} from './CityForm';
import {TodayForecast} from './TodayForecast';
import {FutureForecast} from './FutureForecast';

const generateVDOM = ([formVNode, todayVNode, futureVNode]) => div(".main-container", [
        formVNode,
        todayVNode,
        futureVNode
    ])

const view = (locationDOM$, todayForecastDOM$, futureForecastDOM$) => {
    return xs.combine(locationDOM$, todayForecastDOM$, futureForecastDOM$)
             .map(combinedStreams => generateVDOM(combinedStreams))
             .startWith(h1("Loading..."));
}

const main = sources => {
    const cityLens = {
        get: state => state,
        set: (state, childState) => childState
    }

    const locationSink = isolate(CityForm, {onion: cityLens})(sources);
    const todayForecastSink = isolate(TodayForecast, {onion: cityLens})(sources);
    const futureForecastSink = isolate(FutureForecast, {onion: cityLens})(sources);
    
    const locationReducer$ = locationSink.onion;
    const httpRequest$ = locationSink.HTTP;

    const vdom$ = view(locationSink.DOM,
                       todayForecastSink.DOM,
                       futureForecastSink.DOM);
    
    return {
        DOM: vdom$,
        HTTP: httpRequest$,
        onion: locationReducer$
    }
}

const drivers = {
  DOM: makeDOMDriver('#app'),
  HTTP: makeHTTPDriver()
};

const mainOnionified = onionify(main);

run(mainOnionified, drivers);
