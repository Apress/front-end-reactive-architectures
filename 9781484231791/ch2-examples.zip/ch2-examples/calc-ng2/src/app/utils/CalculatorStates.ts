export const FIRST_OPERATION:string = "firstOperation";
export const IN_PROGRESS_OPERATION:string = "inProgressOperation";