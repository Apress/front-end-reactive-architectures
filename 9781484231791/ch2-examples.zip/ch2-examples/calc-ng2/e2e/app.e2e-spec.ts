import { CalcNg2Page } from './app.po';

describe('calc-ng2 App', () => {
  let page: CalcNg2Page;

  beforeEach(() => {
    page = new CalcNg2Page();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
