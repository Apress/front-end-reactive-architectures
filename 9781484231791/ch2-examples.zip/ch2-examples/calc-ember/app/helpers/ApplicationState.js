export default {
    FIRST_OPERATION: "firstOpeartion",
    CALCULATING: "calculating"
}