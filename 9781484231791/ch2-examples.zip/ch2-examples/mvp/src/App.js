import CalculatorPresenter from "./presenters/CalculatorPresenter";
import CalculatorModel from "./models/CalculatorModel";
import Calculator from "./views/Calculator.jsx";

export default class App{
    constructor(){
        const mainModel = new CalculatorModel();
        let mainPresenter = new CalculatorPresenter();
        mainPresenter.init(mainModel, Calculator);
    }
}

let app = new App();