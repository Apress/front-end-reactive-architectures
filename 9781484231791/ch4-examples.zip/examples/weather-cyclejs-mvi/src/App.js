import xs from 'xstream';
import {run} from '@cycle/run';
import {makeDOMDriver, div, h1, h2, h3, img, p, input, button} from '@cycle/dom';
import {makeHTTPDriver} from '@cycle/http';
import moment from 'moment';

const CATEGORY = "forecast";
const INIT_CITY = "London";

const getForm = () => div(".form", [
    input("#location-input"),
    button("#location-btn", "get forecasts")
])

const generateNext5Days = forecasts => {
    const list = forecasts.map(forecast => {
        return div(".forecast-box", [
            h3(moment(forecast.date).format("dddd Do MMM")),
            p(`min ${forecast.day.mintemp_c}°C - max ${forecast.day.maxtemp_c}°C`),
            img(".forecast-img", {
                props: {
                    src: `http:${forecast.day.condition.icon}`
                }
            }),
            p(".status", forecast.day.condition.text)
        ])
    });
    return div(".forecasts-container", list)
}

const generateCurrentForecast = forecast => div(".current-forecast-container", [
     div(".today-forecast", [
             img(".forecast-img", {
                props: {
                    src: `http:${forecast.condition.icon}`
                }
            }),
            p(".status", forecast.condition.text)
        ]),
        h3(moment(forecast.last_updated).format("dddd Do MMMM YYYY")),
        h2(`${forecast.temp_c}°C`),
        p(`humidity: ${forecast.humidity}%`)       
    ])

const generateVDOM = data => div(".main-container", [
        h1(`Your forecasts in ${data.city}`),
        getForm(),
        generateCurrentForecast(data.current),
        generateNext5Days(data.forecast)
    ])  

const parseResponse = response => JSON.parse(response.text);
const simplifyData = data => {
                                return {
                                    city: data.location.name,
                                    current: data.current,
                                    forecast: data.forecast.forecastday
                                }
                            }

const getRequest = city => {
    return {
        url: `http://api.apixu.com/v1/forecast.json?key=04ca1fa2705645e4830214415172307&q=${city}&days=7`,
        category: CATEGORY
    }
}

const model = (actions, HTTP) => {
    return HTTP.select(CATEGORY)
               .flatten()
               .map(parseResponse)
               .map(simplifyData)
}

const intent = DOM => {
    const input$ = DOM.select("#location-input").events("focusout")
                              .map(evt => evt.target.value);
    const btn$ = DOM.select("#location-btn").events("mousedown");                              
    return {
        request$: xs.combine(input$, btn$)
                    .map(([city, mouseEvt])=> getRequest(city))
                    .startWith(getRequest(INIT_CITY)),
        
    }
}

const view = state$ => {
    return state$.map(generateVDOM)
                 .startWith(h1("Loading..."))
}

const main = sources => {
    const actions = intent(sources.DOM);
    const state$ = model(actions, sources.HTTP)
    const vdom$ = view(state$);

    return {
        DOM: vdom$,
        HTTP: actions.request$
    }
}

const drivers = {
  DOM: makeDOMDriver('#app'),
  HTTP: makeHTTPDriver()
};

run(main, drivers);